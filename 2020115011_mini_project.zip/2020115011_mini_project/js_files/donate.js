
 function validate()
 {
	 var name=document.getElementById("name").value;
	 var address=document.getElementById("address").value;
	 var phone=document.getElementById("phone").value;
	 var email=document.getElementById("email").value;
	 var amount=document.getElementById("amount").value;
	 var card_no=document.getElementById("card_no").value;
	 var date=document.getElementById("date").value;
	 var cvv=document.getElementById("cvv").value;
	 if (name=="")
	 {
		 alert('UserName Cannot Be Empty');
		 return false;
	 }
	if (address=="")
	 {
		 alert('Address Cannot Be Empty');
		 return false;
	 }
	if (phone=="")
	 {
		 alert('Mobile Number Cannot Be Empty');
		 return false;
	 }
	 if (email=="")
	 {
		 alert('Email Cannot Be Empty');
		 return false;
	 }
   if(phone.length<10 || phone.length>10)
	 {
		 alert('Mobile No. should contain 10 digits');
		 return false;
	 }
	if(amount=="")
	 {
		 alert('No Amount has been entered');
		 return false;
	 }
   if (card_no=="")
	 {
		 alert('Card Number is not entered');
		 return false;
	 }
 if(card_no.length<16 || card_no.length>16 )
	 {
		 alert('Card No.should contain 16 digits');
		 return false;
	 }
	if(cvv=="")
	 {
		 alert('CVV cannot be empty');
		 return false;
	 }
	  if(cvv.length<3 || cvv.length>3)
	 {
			 alert('CVV should contain 3 digits');
			 return false;
	 } 
	 if(date=="")
	 {
		 alert('Expiration date is not mentioned');
		 return false;
	 } 
 else{
	 alert('Thanks for your Contribution!');
	 return true;
	}
  
 }