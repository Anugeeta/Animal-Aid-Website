<?php
    session_start();
  
    $con = mysqli_connect("localhost","root","","Product_details");

    if (isset($_POST["add"])){
        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($_GET["id"],$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                    'product_id' => $_GET["id"],
                    'item_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'item_quantity' => $_POST["quantity"],
                );
                $_SESSION["cart"][$count] = $item_array;
                echo '<script>alert("Product added to Cart")</script>';
                   echo '<script>window.location="shop.php"</script>';
            }
            else{
                echo '<script>alert("Product is already Added to Cart")</script>';
                echo '<script>window.location="shop.php"</script>';
            }
        }else{
            $item_array = array(
                'product_id' => $_GET["id"],
                'item_name' => $_POST["hidden_name"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][0] = $item_array;
        }
        
    }
   
    

    if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
            foreach ($_SESSION["cart"] as $keys => $value){
                if ($value["product_id"] == $_GET["id"]){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed..!")</script>';
                    echo '<script>window.location="shop.php"</script>';
                }
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Anugeeta(2020115011)">
   
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    
    <title>Shopping Cart</title>

    
    <style>
           *{
            font-family: sans-serif;
        }
        .product{
            border: 1px solid #eaeaec;
            margin: -1px 19px 3px -1px;
            padding: 10px;
            text-align: center;
            background-color: #efefef;
        }
        table, th, tr{
            text-align: center;
        }
       
        h2{
            text-align: center;
            color: #66afe9;
            background-color: #efefef;
            padding: 2%;
        }
        table th{
            background-color: #efefef;
        }
        .container{
            float:left;
            width:30%;
            margin-left:10px;
        }
        .content-table{
            float:right;
            width:70%;
            margin-top:0%;
           
        }
                
  .content-table {
  border-collapse: collapse;
  margin: -1600px 0;
  font-size: 1em;
  min-width: 400px;
  border-radius: 5px 5px 0 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
  margin-left:20px;
  background-color:lightgrey;
}

.content-table thead tr {
  background-color:#063247;
  color: white;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 15px 50px;
}

.content-table tbody tr {
  border-bottom: 1px solid #063247;
}



.content-table tbody tr:last-of-type {
  border-bottom: 2px solid #063247;
}

.content-table tbody tr.active-row {
  font-weight: bold;
  color: #063247;
}
h3{
    text-align:center;
}
.remove{
    padding:6px;
    background-color:red;
    color:white;
    cursor: pointer;
}
.remove:hover{
  background-color:grey;
}
 span{
     animation:none;
 }
.add_to_cart
{
    padding: 6px;
    background-color:green;
    color:white;
    cursor:pointer;

} 

.purchase{
  margin-left:600px;
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
  padding-right:15px;
  padding-left:15px;
}


.purchase{
  color:rgb(250, 248, 248);
}
.purchase:hover{
  background-color: deeppink;
}

</style>
</head>

<body>
<nav>
      <img src="logo.jpg" alt="" width="140">
        <ul>
           <li><a class="active" href="index.html">Home</a></li>
           <li><a href="sub_folder/about.html">About Us</a></li>
           <li>
              <a href="#">How to help
              <i class="fas fa-caret-down"></i>
              </a>
              <ul>
                 <li><a href="sub_folder/adopt.html">Adopt</a></li>
                 <li><a href="sub_folder/donate.html">Donate</a></li>
                 <li><a href="sub_folder/cruelty_response.html">Cruelty Response</a></li>
                 <li><a href="sub_folder/faq.html">FAQs</a></li>
              </ul>
           </li>
           <li>
              <a href="#">What We Do
              <i class="fas fa-caret-down"></i>
              </a>
              <ul>
                 <li><a href="sub_folder/our_values_mission.html">Our Values & Mission</a></li>
                 <li><a href="sub_folder/ways_to_help.html">Ways to Help</a></li>
                 <li>
                    <a href="shop.php">Shop</a>  
                 </li>
              </ul>
           </li>
           <li><a href="sub_folder/proud_pet_owners.html">Proud Pet Owners</a></li>
           <li><a href="sub_folder/contact.html">Contact Us</a></li>
        </ul>
     </nav>
     <br/>
    <div class="container">
        <h2>Shopping Cart</h2><br/>
        <?php
            $query = "SELECT * FROM product ORDER BY id ASC ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div>

                        <form method="post" action="shop.php?action=add&id=<?php echo $row["id"]; ?>">

                            <div class="product">
                                <img src="<?php echo $row["image"]; ?>">
                                <h5><?php echo $row["pname"]; ?></h5>
                                <h5><?php echo "Rs." . $row["price"]; ?></h5>
                                <input type="number" name="quantity" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["pname"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                                <button type="submit" name="add" onclick="add_to_cart()" class="add_to_cart">Add to Cart</button>
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }
        ?>

        </div>

        <div class="content-table"><h3><br/>Shopping Cart Details<br/><br/></h3>
        <div>
            <table>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price Details</th>
                <th>Total Price</th>
                <th>Remove Item</th>
            </tr>

            <?php
                if(!empty($_SESSION["cart"])){
                    $total = 0;
                    foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                        <tr>
                            <td><?php echo $value["item_name"]; ?></td>
                            <td><?php echo $value["item_quantity"]; ?></td>
                            <td>Rs. <?php echo $value["product_price"]; ?></td>
                            <td>
                                Rs. <?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>
                            <td><a href="shop.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span class="remove">Remove</span></a></td>

                        </tr>
                        <?php
                        $total = $total + ($value["item_quantity"] * $value["product_price"]);
                    }
                        ?>
                        <tr>
                            <td >Total</td>
                            <th >Rs.<?php echo number_format($total, 2); ?></th>
                            <td></td>
                         </tr>
                        <?php
                    }
            
                ?>
            </table>
        </div>
  
  
  <?php 
  if(isset($_SESSION['cart']) && count($_SESSION['cart'])==0)
  {
      echo "<br/><h3>No items on cart</h3>";
  }
  if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0)
  {
  ?>
  
 
  <form action="admin-login.php" method='POST'>
 
  <button class="purchase" name="purchase">Next</button><br/><br/>
 
  </form>
  <?php

  }


  ?>
    
  </div>
</body>
</html>

