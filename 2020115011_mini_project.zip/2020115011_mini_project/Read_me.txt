
Home page: 
   localhost/2020115011_mini_project/index.html
 

Login/Signup page credentials:(This page will appear on clicking 'next' button after selecting the products in shop.php)
  Admin Name: Anugeeta
  Password:12345

Other html pages other than index.html are placed in the 'sub_folder'.

    